﻿using System.Text;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Web;
using Microsoft.ProjectOxford.SpeakerRecognition.Contract.Identification;
using System.IO;
using System;
using Microsoft.ProjectOxford.SpeakerRecognition;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;

namespace SPIDIdentification
{
    class StaticClass
    {
        public static SpeakerIdentificationServiceClient _serviceClient { get; private set; }

        static async Task<Guid> CreateGuid()
        {
            CreateProfileResponse creationResponse = await _serviceClient.CreateProfileAsync("en-US");
            Profile profile = await _serviceClient.GetProfileAsync(creationResponse.ProfileId);
            return profile.ProfileId;
        }
        
        public static void OnLoad()
        {

            //System.Diagnostics.Debugger.Break();

            _serviceClient = null;
            SubscriptionKey sK = new SubscriptionKey();
            string sKey = sK.GetSubscriptionKeyFromIsolatedStorage();

            if (sKey == null)
            {
                InputBoxResult result = InputBox.Show("Please enter the Speaker Identification Subscription key.", "Speaker Identification Subscription");
                sKey = result.Text;
                sK.SaveSubscriptionKeyToIsolatedStorage(sKey);
            }
            
            if (sKey != null || sKey != "")
                _serviceClient = new SpeakerIdentificationServiceClient(sKey);
        }

        public static async Task<string> EnrollSpeaker(string filePath, string shortAudio, string pid)
        {
            //System.Diagnostics.Debugger.Break();

            string retVal = "";

            if (_serviceClient == null)  OnLoad();

            Guid profileId;
            if (pid == string.Empty)
            {
                profileId = await CreateGuid();
            }
            else
            {
                profileId = new Guid(pid);
            }

            OperationLocation processPollingLocation;
            using (Stream audioStream = File.OpenRead(filePath))
            {
                processPollingLocation = await _serviceClient.EnrollAsync(audioStream, profileId, shortAudio.ToUpper() == "TRUE" ? true : false );
            }

            EnrollmentOperation enrollmentResult;
            int numOfRetries = 10;
            TimeSpan timeBetweenRetries = TimeSpan.FromSeconds(5.0);
            while (numOfRetries > 0)
            {
                await Task.Delay(timeBetweenRetries);
                enrollmentResult = await _serviceClient.CheckEnrollmentStatusAsync(processPollingLocation);

                if (enrollmentResult.Status == Status.Succeeded)
                {
                    retVal = profileId.ToString() + "Enrolled";
                    //retVal = "Enrolled";
                    break;
                }
                else if (enrollmentResult.Status == Status.Failed)
                {
                    //throw new EnrollmentException(enrollmentResult.Message);
                    retVal = enrollmentResult.Message;
                }
                numOfRetries--;
            }
            if (numOfRetries <= 0)
            {
                //throw new EnrollmentException("Enrollment operation timeout.");
                retVal = "Enrollment operation timeout.";
            }

            return retVal;
        }

        public static async Task<string> GetIdentity(string filePath, string shortAudio)
        {
            //System.Diagnostics.Debugger.Break();

            string retVal = "";

            if (_serviceClient == null) OnLoad();

            try
            {
                if (filePath == "")
                    return ("No File Provided.");

                if (!File.Exists(filePath))
                    return ("File does not exist.");

                Profile[] allProfiles = await _serviceClient.GetProfilesAsync();
                List<Guid> testProfileIdsList = new List<Guid>();                
                for (int i = 0; i < allProfiles.Length; i++)
                {
                    if (allProfiles[i].EnrollmentStatus == Microsoft.ProjectOxford.SpeakerRecognition.Contract.EnrollmentStatus.Enrolled)
                        testProfileIdsList.Add(allProfiles[i].ProfileId);
                }
                Guid[] testProfileIds = testProfileIdsList.ToArray();

                OperationLocation processPollingLocation;
                using (Stream audioStream = File.OpenRead(filePath))
                {
                    filePath = "";
                    processPollingLocation = await _serviceClient.IdentifyAsync(audioStream, testProfileIds, shortAudio.ToUpper() == "TRUE" ? true : false);
                }

                IdentificationOperation identificationResponse = null;
                int numOfRetries = 10;
                TimeSpan timeBetweenRetries = TimeSpan.FromSeconds(5.0);
                while (numOfRetries > 0)
                {
                    await Task.Delay(timeBetweenRetries);
                    identificationResponse = await _serviceClient.CheckIdentificationStatusAsync(processPollingLocation);

                    if (identificationResponse.Status == Status.Succeeded)
                    {
                        break;
                    }
                    else if (identificationResponse.Status == Status.Failed)
                    {
                        throw new IdentificationException(identificationResponse.Message);
                    }
                    numOfRetries--;
                }
                if (numOfRetries <= 0)
                {
                    //throw new Exception("Identification operation timeout.");
                    throw new IdentificationException("Identification operation timeout.");
                }

                retVal = ("Identification Done.");

                retVal = identificationResponse.ProcessingResult.IdentifiedProfileId.ToString();
                retVal += "|" + identificationResponse.ProcessingResult.Confidence.ToString();
            }
            catch (IdentificationException ex)
            {
                //window.Log("Speaker Identification Error: " + ex.Message);
                //retVal = "Speaker Identification Error: " + ex.Message;

                retVal = await EnrollSpeaker(filePath, shortAudio, "");
            }
            catch (Exception ex)
            {
                //window.Log("Error: " + ex.Message);
                retVal = "Error: " + ex.Message;
            }

            return retVal;
        }
    }

}
